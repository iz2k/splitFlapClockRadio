sudo rm -rf /usr/share/iz2k/splitFlapClockRadioFrontend
echo " -> Install component"
sudo mkdir /usr/share/iz2k/splitFlapClockRadioFrontend
sudo cp version.txt /usr/share/iz2k/splitFlapClockRadioFrontend/
sudo cp -r public /usr/share/iz2k/splitFlapClockRadioFrontend/
echo "Done"
