echo " -> Check and Stop service"
sudo systemctl stop splitFlapClockRadioBackend.service
echo " -> Check and Remove old version"
sudo rm -rf /usr/share/iz2k/splitFlapClockRadioBackend
sudo mkdir /usr/share/iz2k/splitFlapClockRadioBackend
echo " -> Create virtual environment"
sudo python3 -m venv /usr/share/iz2k/splitFlapClockRadioBackend/venv
sudo cp version.txt /usr/share/iz2k/splitFlapClockRadioBackend/
echo " -> Install component"
sudo /usr/share/iz2k/splitFlapClockRadioBackend/venv/bin/pip install splitFlapClockRadioBackend-1.0-py3-none-any.whl
echo " -> Create executable script"
sudo touch /usr/share/iz2k/splitFlapClockRadioBackend/splitFlapClockRadioBackend.sh
echo "/usr/share/iz2k/splitFlapClockRadioBackend/venv/bin/python -m splitFlapClockRadioBackend \"\$@\"" | sudo tee -a /usr/share/iz2k/splitFlapClockRadioBackend/splitFlapClockRadioBackend.sh | grep donotshowanythinginbash
sudo chmod +x /usr/share/iz2k/splitFlapClockRadioBackend/splitFlapClockRadioBackend.sh
echo " -> Create symbolic link"
sudo ln -f -s /usr/share/iz2k/splitFlapClockRadioBackend/splitFlapClockRadioBackend.sh /usr/bin/splitFlapClockRadioBackend
echo " -> Create splitFlapClockRadioBackend Service"
cat << EOF | sudo tee /etc/systemd/system/splitFlapClockRadioBackend.service | grep donotshowanythinginbash
[Unit]
Description = splitFlapClockRadio BackEnd SW
After = network.target

[Service]
ExecStart = /usr/share/iz2k/splitFlapClockRadioBackend/venv/bin/python -m splitFlapClockRadioBackend
WorkingDirectory = /usr/share/iz2k/splitFlapClockRadioBackend
StandardOutput = inherit
StandardError = inherit
Restart = always
User = root

[Install]
WantedBy = multi-user.target
EOF
echo " -> Enable splitFlapClockRadioBackend Service"
sudo systemctl daemon-reload
sudo systemctl enable splitFlapClockRadioBackend.service
sudo systemctl start splitFlapClockRadioBackend.service
echo "Done!"
